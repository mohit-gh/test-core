<?php 
/*echo chr(43);
$a = "PHP";
$a = $a + 1;
echo $a;*/
//echo date('D-M-Y', strtotime('18 sept 2018'));
/*$abc = 'Mohit';
echo 'abc<br/>';
echo 'abc $abc <br/>';
echo "abc $abc";*/


//echo date('d-M-Y', strtotime('-9 days',strtotime('Monday') ) );

$num = "3.14";
$int = (int)$num;
$str = (float)$num;
echo "$int--$str";

?>
