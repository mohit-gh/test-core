<?php

  class Books {
    
      public function name() {
          echo "Drupal Book";
      }
      
      public function price() {
          echo "900 Rs/-";
      }
  
  }
  
  //To create php Object we have to use a new operator. Here php object is the object of the Books Class.

  class Mobile {
    /* Member Variables */
    var $price;
    var $title;
   
    /* Member functions */
    function setPrice($p) {
      $this->price = $p;
    }
    function getPrice() {
      echo " ($this->price)<br/> ";
    }
    function setTitle($t) {
      $this->Title = $t;
    }
    function getTitle() {
      echo $this->Title;
    }
    
  }
  

  //Books Class
  $book_obj = new Books();
  $book_obj->name(); 
  $book_obj->price();


  //Mobile Class
  echo "<hr>";
  $mi = new Mobile();
  $iphone = new Mobile();
  
  $iphone->setPrice(88000);
  $iphone->setTitle(Iphone6s);
  $mi->setPrice(13999);
  $mi->setTitle(RedmiNote5Pro);
  
  $iphone->getTitle();
  $iphone->getPrice();
  
  $mi->getTitle();
  $mi->getPrice();
?>