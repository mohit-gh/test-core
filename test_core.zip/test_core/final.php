<?php

class baseclass {

	function printMe() {
		echo "This is base class function";
	}
}

class childclass {
	function printMe() {
		echo "This is childclass printme() function";
	}
	
}

$obj = new childclass();
$obj->printMe();