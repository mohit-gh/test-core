<script>
	window.location.replace("http://stackoverflow.com");
</script>
<?php
echo "hello";

?>
