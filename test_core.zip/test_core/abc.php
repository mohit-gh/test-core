
<?php
$username= 'radhey90kumar@gmail.com';
$password= '9928701068';
 
//Connect Gmail feed atom
$url = "https://mail.google.com/mail/feed/atom"; 
 
// Send Request to read email 
 $curl = curl_init();
 curl_setopt($curl, CURLOPT_URL, $url);
 curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
 curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($curl, CURLOPT_USERPWD, $username . ":" . $password);
 curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
 curl_setopt($curl, CURLOPT_ENCODING, "");
 $curlData = curl_exec($curl);
 curl_close($curl);
	
 $emails = new SimpleXmlElement($curlData);
 print_r($emails);
 die;
 echo "<ul>";
 foreach($emails->entry as $entry)
 {
  echo '<li><p>'. $entry->title.'<br>';
  echo $entry->summary;
  echo '</p></li>';
 }
 echo "</ul>";
?>