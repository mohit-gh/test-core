<?php

  class A {
      public function printItem($str) {
          echo "Hi : $str ";
      }
      public function printPHP() {
          echo "I am From WWE <br/>";      
      }

}

class B Extends A {
    public function printPHP() {
        echo "I am From UFC";
    }

}

class MA {

  public function age() {
    echo "Class A age is 89 <br/>";
  }

}

class MB extends MA {
  public function sonage() {
    echo "Class B age is 50 <br/>";
  }

}

class MC Extends MB {
  public function grandsonage() {
    echo "Class C age is 20";
  }
  
  public function ageHistory() {
      $this->age();
      $this->sonage();
      $this->grandsonage();
  }

}

//Single Level Inheritance
$superstar = new A();
$fighter = new B();

$superstar->printItem('Roman Reigns');
$superstar->printPHP();

$fighter->printItem('Brock Lesnar');
$fighter->printPHP();
echo "<hr/>";

//MultiLevel Inheritance
$multi_obj = new MC();
$multi_obj->ageHistory();
 
 
?>