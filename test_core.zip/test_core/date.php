<?php
date_default_timezone_set('Asia/Kolkata');
echo date("d-M-y")."<br>";
echo date("h:i:sa")."<br>";
echo date('d-m-Y', strtotime("Monday"))."<br/>";
echo date('d/m/Y', strtotime("+3 Weeks"))."<br/>";
//strtotime with two parameters
$next_day = strtotime("Monday");
echo date('d-M-Y', strtotime("+10 days", $next_day))."<br/>";
$bd = mktime(03,30,9,05,8,1993);
echo "MK-Time ".date("d-M-y h:i:sa", $bd)."<br/>";
echo date('d-m-Y', strtotime("12-08-2017 -1 year"));
?>