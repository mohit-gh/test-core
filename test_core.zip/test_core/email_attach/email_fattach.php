<?php

if(isset($_POST['send_attach'])) {

$name = $_POST['name1'];
$mailto = $_POST['email1'];
$message = $_POST['msg'];
$subject = "File Attachment Example";

if(isset($_FILES['afile'])){
      $errors= array();
      $file_name = $_FILES['afile']['name'];
      $file_size =$_FILES['afile']['size'];
      $file_tmp =$_FILES['afile']['tmp_name'];
      $file_type=$_FILES['afile']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['afile']['name'])));
      
      /*$expensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }*/
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"file_upl/".$file_name);
         echo "<pre>";
         print_r(move_uploaded_file($file_tmp,"http://localhost/test_core/email_attach/file_upl/".$file_name));
         echo "</pre>";
         die;
         echo "File Uploaded successfully <br/>";
      }else{
         print_r($errors);
      }
   }
}
    /*$path = 'http://localhost/test_core/email_attach/file_upl';
    $file = $path . "/" . $file_name;
    
    $content = file_get_contents($file);
    $content = chunk_split(base64_encode($content));

    // a random hash will be necessary to send mixed content
    $separator = md5(time());

    // carriage return type (RFC)
    $eol = "\r\n";

    // main header (multipart mandatory)
    $headers = "From: Mohit Tech <mohitbca11@gmail.com>" . $eol;
    $headers .= "MIME-Version: 1.0" . $eol;
    $headers .= "Content-Type: multipart/mixed; boundary=\"" . $separator . "\"" . $eol;
    $headers .= "Content-Transfer-Encoding: 7bit" . $eol;
    $headers .= "This is a MIME encoded message." . $eol;

    // message
    $body = "--" . $separator . $eol;
    $body .= "Content-Type: text/plain; charset=\"iso-8859-1\"" . $eol;
    $body .= "Content-Transfer-Encoding: 8bit" . $eol;
    $body .= $message . $eol;
    $body .= "Thank you ".$name." Here is your attachment you want". $eol;

    // attachment
    $body .= "--" . $separator . $eol;
    $body .= "Content-Type: application/octet-stream; name=\"" . $file_name . "\"" . $eol;
    $body .= "Content-Transfer-Encoding: base64" . $eol;
    $body .= "Content-Disposition: attachment" . $eol;
    $body .= $content . $eol;
    $body .= "--" . $separator . "--";

    //SEND Mail
    if (mail($mailto, $subject, $body, $headers)) {
        echo "Mail Send"; // or use booleans here
    } else {
        echo "mail send ... ERROR!";
        print_r( error_get_last() );
    }*/

?> 

<HTML>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body>
<div class="container">
<form action="" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleInputName">Name</label>
    <input type="text" name="name1" class="form-control" id="exampleInputName1" placeholder="Name" required="">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input name="email1" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required="">
  </div>
  
  <div class="form-group">
    <label for="exampleMessage">Message</label>
    <textarea name="msg" class="form-control" id="message" rows="3" required=""></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputFile">File input</label>
    <input type="file" name="afile" class="form-control-file" id="exampleInputFile" aria-describedby="fileHelp" required="">
    <small id="fileHelp" class="form-text text-muted">This is some placeholder block-level help text for the above input. It's a bit lighter and easily wraps to a new line.</small>
  </div>
  <button name="send_attach" type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</body>
</HTML>