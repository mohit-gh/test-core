<?php
	if(isset($_POST['fname'])) {
		print_r($_POST);
	}
?>
<html>
	<head>
		<title>Submit A Form Without submit button</title>
	</head>
	<body>
		<form id="myfrm" action="" method="post">
			<input type="text" required="" name="fname"/><br/>
			<input type="email" name="umail"/><br/>
			<input type="button" name="sbmtbtn" onclick="sbmtFrm()" value="Click"/>
		</form> 
	</body>
</html>
<script>
function sbmtFrm() {
	document.getElementById('myfrm').submit();
}
</script>