<?php
	date_default_timezone_set('America/Los_Angeles');
?>
<html>
	<head></head>
	<body>
		<h2>Add Two Numbers <?php echo date('Y-m-d'); ?></h2>
		<form action="add.php" method="post" id="add">
			<input type="text" name="first"> +
			<input type="text" name="second">
			<input type="submit" value="Work this out">
		</form>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.0/jquery.min.js"></script>
		<script src="global.js"></script>
	</body>
</html>