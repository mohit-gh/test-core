<?php
header('content-type: text/javascript');

$resp = array(
	'success' => false,
	'result' => 0
);

if(isset($_POST['first'], $_POST['second'])) {
	$first = (int)$_POST['first'];
	$second = (int)$_POST['second'];

	$resp['success'] = true;
	$resp['result'] = $first + $second;

}

echo json_encode($resp);

?>