<?php


for($i=1;$i<=5;$i++) {
	for($j=1;$j<=$i;$j++) {
		echo '*';
	}
	echo "<br>";
}
echo "<hr>";

for($i=1;$i<=5;$i++) {

	for($k=$i;$k<5;$k++) {
		echo "&nbsp";
	}
	for($j=1;$j<=$i;$j++) {
		echo "* ";
	}
	echo "<br/>";
}
echo '<hr>';
for($i=1;$i<=5;$i++) {
	for($k=$i;$k<5;$k++) {
		echo '&nbsp';
	}
	for($j=1;$j<=$i;$j++) {
		echo '*';
	}
	echo '<br/>';
}

echo '<hr>';

for($i=1;$i<=5;$i++) {

	for($k=$i;$k>1;$k--) {
		echo '&nbsp';
	}

	for($j=5;$j>=$i;$j--) {
		echo '*';
	}
	echo "<br>";
}
echo '<hr>';
$num = 1;
for($i=1;$i<=5;$i++) {
	for($k=$i;$k<5;$k++) {
		echo '&nbsp';
	}
	for($j=1;$j<=$i;$j++) {
		echo "$num ";
		++$num;
	}
	echo '<br>';

}

echo '<hr>';

for($i=1;$i<=5;$i++) {

	for($k=$i;$k<5;$k++) {
		echo '&nbsp';
	}

	for($j=1;$j<=$i;$j++) {
		echo "$i ";
	}
	echo '<br>';
}
echo '<hr>';
for($i=1;$i<=5;$i++) {
	for($k=$i;$k<5;$k++) {
		echo '&nbsp';
	}
	for($j=1;$j<=$i;$j++) {
		echo "$j ";
	}
	echo '<br/>';
}

echo '<hr>';
$num = 1;
for($i=1;$i<=5;$i++) {
	for($k=$i;$k<5;$k++) {
		echo '&nbsp';
	}
	for($j=1;$j<=$i;$j++) {
		echo "$num ";
		$num += 2;
	}
	echo '<br>';
}

echo '<hr>';
for($i=1;$i<=5;$i++) {
	for($j=1;$j<=4;$j++) {
		echo '*';
	}
	echo '<br/>';
}
echo '<hr>';
$num=1;
for($i=1;$i<=5;$i++) {
	for($j=1;$j<=$num;$j++) {
		echo '*';
	}
	if($i>2) {
		$num--;
	} else {
		$num++;
	}
	echo '<br/>';
}
